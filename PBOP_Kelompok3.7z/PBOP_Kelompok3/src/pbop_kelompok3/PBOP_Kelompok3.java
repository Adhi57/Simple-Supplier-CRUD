/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbop_kelompok3;

/**
 *
 * @author Administrator
 */
public class PBOP_Kelompok3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MenuUtama menuUtama = new MenuUtama();
        
        menuUtama.setVisible(true);
    }
    
}
